package personajes;

import bitacora.Bitacora;
import bitacora.GestorDeInformacion;
import efectos.ObjetivoFijo;
import juegoDePelea.Arma;

public class Pistolero extends Personaje {
	boolean habilidadActiva = false;
	
	public Pistolero(String nombre, int vidaActual, Arma arma, int nivel,GestorDeInformacion gestorDeInformacion) {
		super("PISTOLERO", nombre, 100, vidaActual, 7, arma, nivel, gestorDeInformacion,"Dispara al inicio del turno a un"
				+ " objetivo hasta que reciba daño");
	}
	
	public boolean isHabilidadActiva() {
		return habilidadActiva;
	}

	public void setHabilidadActiva(boolean habilidadActiva) {
		this.habilidadActiva = habilidadActiva;
	}
	
	
	/**
     * Disminuye la cantidad de vida de un personaje vivo, aplica porcentaje de daño extra al ataque 
     * si el enemigo es debil contra el actual tipo de personaje
     * @param personajeEnemigo personaje enemigo a reducir vida
     * @return indica si el ataque fue exitoso
     */
	@Override
	public boolean atacar(Personaje personajeEnemigo) {
		double porcentajeBonificacionAtaque = 0;
		int vidaEnemigo = personajeEnemigo.getVidaActual();
		int poderBase = poderAtaque + arma.getDanoExtra();
		poderBase = poderBase + (poderBase*porcentajeBuffAtaqueBase);
		
		if(vidaEnemigo == 0) { //Sin vida
			return false;
		} else if (personajeEnemigo.getTipo() == "PISTOLERO") { //Enemigo afin
			porcentajeBonificacionAtaque = 0.20;
		}
		
		//Criticos y fallos
		if(Math.random() < arma.getPrecision()) {
			if(Math.random() < arma.getProbabilidadCritico()) {
				//Personaje paralizado
				gestorDeInformacion.imprimirCritico(this, personajeEnemigo);
				personajeEnemigo.setStuneado(true);
			}
		} else {
			gestorDeInformacion.imprimirAtaqueFallido(this, personajeEnemigo);
			poderBase = 0;
			return true;
		}
		
		//Informacion vida restante del enemigo
		int daño = (int) (poderBase+(poderBase*porcentajeBonificacionAtaque));
		int vidaEnemiga = personajeEnemigo.recibirDaño(this,daño);
		recibirExperiencia(5);
		
		return true;
	}
	
	@Override //Solo cambia el habilidadActiva 
	public int recibirDaño(Personaje personaje,int daño) {
		habilidadActiva = false;
		return super.recibirDaño(personaje, daño);
	}
	
	@Override
	public boolean habilidad(Personaje personajeEnemigo) {
		habilidadActiva = true;
		ObjetivoFijo efecto = new ObjetivoFijo(this,personajeEnemigo,gestorDeInformacion);
		if(personajeEnemigo.recibirEfecto(efecto)) {
			recibirExperiencia(7);
			gestorDeInformacion.habilidad(this, "objetivo asegurado", personajeEnemigo);
			return true;
		}
		return false;
	}

}
