package personajes;

import java.lang.runtime.ObjectMethods;
import bitacora.Bitacora;
import bitacora.GestorDeInformacion;

import juegoDePelea.Arma;

public class Espadachin extends Personaje {
		public Espadachin( String nombre, int vidaActual, Arma arma, int nivel,GestorDeInformacion gestorDeInformacion) {
		super("ESPADACHIN", nombre, 80, vidaActual, 10, arma, nivel, gestorDeInformacion,"Ataca 2 veces");
	}
	
		
	/**
     * Disminuye la cantidad de vida de un personaje vivo, aplica porcentaje de daño extra al ataque 
     * si el enemigo es debil contra el actual tipo de personaje
     * @param personajeEnemigo personaje enemigo a reducir vida
     * @return indica si el ataque fue exitoso
     */
	@Override
	public boolean atacar(Personaje personajeEnemigo) {
		double porcentajeBonificacionAtaque = 0;
		int vidaEnemigo = personajeEnemigo.getVidaActual();
		int poderBase = poderAtaque + arma.getDanoExtra();
		poderBase = poderBase + (poderBase*porcentajeBuffAtaqueBase);
		
		if(vidaEnemigo == 0) { //Sin vida
			return false;
		} else if (personajeEnemigo.getTipo() == "PISTOLERO") { //Enemigo afin
			porcentajeBonificacionAtaque = 0.20;
		}
		
		//Criticos y fallos
		if(Math.random() < arma.getPrecision()) {
			if(Math.random() < arma.getProbabilidadCritico()) {
				//Personaje paralizado
				gestorDeInformacion.imprimirCritico(this, personajeEnemigo);
				personajeEnemigo.setStuneado(true);
			}
		} else {
			gestorDeInformacion.imprimirAtaqueFallido(this, personajeEnemigo);
			poderBase = 0;
			return true;
		}
		
		//Informacion vida restante del enemigo
		int daño = (int) (poderBase+(poderBase*porcentajeBonificacionAtaque));
		int vidaEnemiga = personajeEnemigo.recibirDaño(this,daño);
		recibirExperiencia(5);
		
		return true;
	}

	@Override
	public boolean habilidad(Personaje personajeEnemigo) {
		if(personajeEnemigo.estaMuerto()) {
			gestorDeInformacion.imprimirError(personajeEnemigo.getTipo() + " esta muerto");
			return false;
		}
		gestorDeInformacion.habilidad(this, "doble golpe", personajeEnemigo);
		atacar(personajeEnemigo);
		recibirExperiencia(7);
		if(personajeEnemigo.estaMuerto()) {
			return true;
		}
		atacar(personajeEnemigo);
		
		return true;
	}


}
