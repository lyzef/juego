package personajes;

import bitacora.Bitacora;
import bitacora.GestorDeInformacion;
import efectos.Efecto;
import efectos.Fireball;
import juegoDePelea.Arma;

public class Mago extends Personaje {
//9
	public Mago(String nombre, int vidaActual, Arma arma, int nivel, GestorDeInformacion gestorDeInformacion) {
		super("MAGO", nombre, 90, vidaActual, 9, arma, nivel, gestorDeInformacion,"Inflinge 20 de daño y deja quemadura"
				+ "por 2 turnos");
		
	}

	@Override
	public boolean atacar(Personaje personajeEnemigo) {
		double porcentajeBonificacionAtaque = 0;
		int vidaEnemigo = personajeEnemigo.getVidaActual();
		int poderBase = poderAtaque + arma.getDanoExtra();
		poderBase = poderBase + (poderBase*porcentajeBuffAtaqueBase);
		
		if(vidaEnemigo == 0) { //Sin vida
			return false;
		} else if (personajeEnemigo.getTipo() == "PISTOLERO") { //Enemigo afin
			porcentajeBonificacionAtaque = 0.20;
		}
		
		//Criticos y fallos
		if(Math.random() < arma.getPrecision()) {
			if(Math.random() < arma.getProbabilidadCritico()) {
				//Personaje paralizado
				gestorDeInformacion.imprimirCritico(this, personajeEnemigo);
				personajeEnemigo.setStuneado(true);
			}
		} else {
			gestorDeInformacion.imprimirAtaqueFallido(this, personajeEnemigo);
			poderBase = 0;
			return true;
		}
		
		//Informacion vida restante del enemigo
		int daño = (int) (poderBase+(poderBase*porcentajeBonificacionAtaque));
		int vidaEnemiga = personajeEnemigo.recibirDaño(this,daño);
		recibirExperiencia(5);
		
		return true;
	}
	
	@Override
	public boolean habilidad(Personaje personajeEnemigo) {
		Efecto fireball = new Fireball(personajeEnemigo,this,gestorDeInformacion);
		if(personajeEnemigo.recibirEfecto(fireball)) {
			recibirExperiencia(7);
			gestorDeInformacion.habilidad(this, "bola de fuego", personajeEnemigo);
			return true;
		}
		return false;
	}

	

}
