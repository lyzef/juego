package personajes;

import bitacora.Bitacora;
import bitacora.GestorDeInformacion;

import efectos.Efecto;
import juegoDePelea.Arma;
import juegoDePelea.Utilidades;

public abstract class Personaje {
	protected String tipo;
	protected String nombre;
	protected int vidaMaxima;
	protected int vidaActual;
	protected int poderAtaque;
	protected Arma arma;
	protected int nivel; // 1 a 4
	protected int experiencia = 0;
	protected boolean stuneado = false;
	protected Efecto[] efectos = new Efecto[3]; //maximos
	protected int[] requerimientoNiveles = new int[4];
	protected int porcentajeReduccionDeDañoRecibido = 0;
	protected int porcentajeBuffAtaqueBase;
	protected String descripcionHabilidad;
	
	protected GestorDeInformacion gestorDeInformacion;
	
	public Personaje(String tipo, String nombre, int vidaMaxima, int vidaActual, int poderAtaque, Arma arma, int nivel, GestorDeInformacion gestorDeInformacion,String descripcionHabilidad) {
		//Experiencia para subir de nivel (1 -> 4)
		requerimientoNiveles[0] = 0; //1
		requerimientoNiveles[1] = 20; //2
		requerimientoNiveles[2] = 45; //3
		requerimientoNiveles[3] = 101; //4
		
		//Validaciones nivel
		if(nivel == 0) { //Nivel no puede ser 0
			nivel = 1;
		}
		
		if(experiencia < requerimientoNiveles[nivel-1]) { //Igualamos la experiencia con el nivel
			experiencia =  requerimientoNiveles[nivel-1];
		}
		
		//Validaciones vida
		if(vidaActual > vidaMaxima) {
			vidaActual = vidaMaxima;
		} else if(vidaActual < 0) {
			vidaActual = 0;
		}
		this.tipo = tipo;
		this.nombre = nombre;
		this.vidaMaxima = vidaMaxima;
		this.vidaActual = vidaActual;
		this.poderAtaque = poderAtaque;
		this.arma = arma;
		this.nivel = nivel;
		this.gestorDeInformacion = gestorDeInformacion;
		this.descripcionHabilidad = descripcionHabilidad;
	}
	
	//getters y setters
	public String getTipo() {
		return tipo;
	}
	public String getNombre() {
		return nombre;
	}
	public int getVidaMaxima() {
		return vidaMaxima;
	}
	public int getVidaActual() {
		return vidaActual;
	}
	public int getPoderAtaque() {
		return poderAtaque;
	}
	public Arma getArma() {
		return arma;
	}
	public int getNivel() {
		return nivel;
	}
	public int getExperiencia() {
		return experiencia;
	}
	public String getDescripcionHabilidad() {
		return descripcionHabilidad;
	}
	public Efecto[] getEfectos() {
		return efectos;
	}
	public boolean getStuneado() {
		return stuneado;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public void setVidaMaxima(int vidaMaxima) {
		this.vidaMaxima = vidaMaxima;
	}
	public void setVidaActual(int vidaActual) {
		this.vidaActual = vidaActual;
	}
	public void setPoderAtaque(int poderAtaque) {
		this.poderAtaque = poderAtaque;
	}
	public void setStuneado(boolean stuneado) {
		this.stuneado = stuneado;
	}
	public void setArma(Arma arma) {
		this.arma = arma;
	}
	public void setNivel(int nivel) {
		this.nivel = nivel;
	}
	public void setExperiencia(int experiencia) {
		this.experiencia = experiencia;
	}

	/**
     * Imprime las estadisticas actuales del personaje
     */
	public void mostrarEstadisticas() {
		 gestorDeInformacion.imprimir("Personaje Actual = ", false);
		 gestorDeInformacion.imprimirAlFinal(nombre + "(" + tipo + ")");
		 gestorDeInformacion.imprimir("Vida = " + "(" + vidaActual + "/" + vidaMaxima + ")" , true);
		 gestorDeInformacion.imprimir("ATK = " + poderAtaque, false);
		 gestorDeInformacion.imprimirAlFinal("Nivel = " + nivel);
	}
	
	public abstract boolean atacar(Personaje personajeEnemigo);
	
	public abstract boolean habilidad(Personaje personajeEnemigo);
	
	/**
     * Administra el daño ejercido por un enemigo, o efecto.
     * @param daño recibido
     * @return vida restante
     */
	public int recibirDaño(Personaje personaje,int daño) {
		daño = (daño - (daño*porcentajeReduccionDeDañoRecibido));
		int vida = vidaActual-daño;
		if(vida < 0) {
			vida = 0;
			gestorDeInformacion.imprimirMuerte(personaje, this,daño);
		} else {
			recibirExperiencia(3); //Experiencia por recibir daño y vivir
			gestorDeInformacion.imprimirGolpe(personaje, this, daño);
		}
		vidaActual = vida;
		return vidaActual;
	}
	
	/**
     * Aumenta el poder de ataque, vida maxima y restaura la vida, Determina si el jugador tiene la experiencia
     * necesaria para subir de nivel
     */
	public void recibirExperiencia(int experienciaGanada) { 
		if(nivel == 4) {
			//Nivel maximo ya alcanzado
			return;
		}
		experiencia += experienciaGanada;
		
		for(int i = requerimientoNiveles.length-1; i >= 0; i--) {//for que revisa en que nivel debe de estar 
			if(experiencia >= requerimientoNiveles[i]) {
				if(nivel == i+1) { //No sube de nivel
					break;
				}
				nivel = i+1; //Sube de nivel
				gestorDeInformacion.imprimirSubirNivel(this, nivel);
				vidaMaxima += vidaMaxima * 0.15;
				vidaActual = vidaMaxima;
				poderAtaque += poderAtaque * 0.2;
				break;
			}
		}
		
		
	}
	
	/**
     * Recibe un efecto y ejecuta en caso de haber un efecto instantaneo
     * maneja la cantidad de efectos
     * @param efecto Efecto recibido por una habilidad
     * @return si el efecto fue recibido
     */
	public boolean recibirEfecto(Efecto efecto) { 
		if(Utilidades.listaLlena(efectos)) {
			gestorDeInformacion.imprimirError("Tiene demasiados efectos el personaje 🗣️");
			return false;
		}
		
		for(int i = 0; i < efectos.length; i++) {
			if(efectos[i] != null && efectos[i].getClass() == efecto.getClass()) {
				efectos[i] = efecto;
				System.out.println("Efecto actualizado!");
				efecto.ejecutar();
				return true;
			}
		}
		
		int indice = Utilidades.espacioVacioLista(efectos);
		efectos[indice] = efecto;
		efecto.ejecutar();
		return true;
	}
	
	public boolean estaMuerto() {
		if(vidaActual == 0) {
			return true;
		} 
		return false;
	}
	
}
