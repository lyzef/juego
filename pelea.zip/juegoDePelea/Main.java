package juegoDePelea;

import java.util.Scanner;
import bitacora.Bitacora;
import bitacora.GestorDeInformacion;
import personajes.Espadachin;
import personajes.Personaje;
import personajes.Pistolero;


public class Main {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		
		GestorDeInformacion gestorDeInformacion = new GestorDeInformacion(50);
		GestorPersonajes gestorPersonajes = new GestorPersonajes(gestorDeInformacion);
		gestorDeInformacion.setGestorPersonajes(gestorPersonajes);
		Partida partida = new Partida(gestorDeInformacion, gestorPersonajes);
		
		String textoInicio = "1.- Ver personajes disponibles \r\n"
				+ "2.- Elegir personajes del jugador 1 \r\n"
				+ "3.- Elegir personajes del jugador 2 \r\n"
				+ "4.- Iniciar combate \r\n"
				+ "5.- Ver reglas del juego \r\n"
				+ "6.- Salir\r\n"
				+ "- Elige una opcion -";
		
		boolean seguir = true;
		do {
			gestorDeInformacion.imprimirTitulo("MENU", "=");
			gestorDeInformacion.imprimir(textoInicio, true);
			String eleccion = in.nextLine();
			if(eleccion.isBlank()) {
				eleccion = "DEFAULT";
			}
			
			switch(eleccion.charAt(0)) {
			case '1': //Personajes disponibles
				gestorPersonajes.verYElegirEstadisticasPersonajeBase();
				break;
			case '2':
				gestorPersonajes.elegirPersonajes(1);
				break;
			case '3':
				gestorPersonajes.elegirPersonajes(2);
				break;
			case '4':
				partida.iniciarPartida();
				break;
			default:
				System.out.println("selecciona una opcion"
						+ "");
			}
		}while(seguir);

	}
	
	
	

}
