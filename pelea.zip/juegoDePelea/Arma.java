package juegoDePelea;

import personajes.Personaje;

/**
 * Representa la clase base para todas las armas usadas por los personajes
 * estas añaden un bonus de ataque y tienen la posibilidad de invalidad una accion de un personaje en el siguiente turno
 * @see Personaje
 */
public class Arma {
	/**Nombre del arma */
	String nombre;
	/** Daño extra*/
	int danoExtra;
	/** Probabilidad de fallar el golpe */
	double precision;
	/** Probabiidad de estunear un personaje enemigo un turno*/
	double probabilidadCritico;
	
	/**
	 *  Crea el arma usado por los personajes
	 *  @param nombre Nombre del arma
	 *  @param danoExtra Daño extra al ataque base del personaje
	 *  @param precision Precision de no falla el personaje el ataque
	 *  @param probabilidadCritico Probabilidad de stunear
	 *  */
	public Arma(String nombre, int danoExtra, double precision, double probabilidadCritico) {
		this.nombre = nombre;
		this.danoExtra = danoExtra;
		this.precision = precision;
		this.probabilidadCritico = probabilidadCritico;
	}
	
	/** Obtiene el nombre del arma
	 * @return nombre del arma
	 **/
	public String getNombre() {
		return nombre;
	}
	/** Obtiene el daño extra del arma
	 * @return Daño extra del arma
	 **/
	public int getDanoExtra() {
		return danoExtra;
	}
	/** Obtiene la precision del arma
	 * @return precision de no fallar un ataque
	 **/
	public double getPrecision() {
		return precision;
	}
	/** Obtiene la probabilidad de stunear
	 * @return probabilidad de stunear
	 **/
	public double getProbabilidadCritico() {
		return probabilidadCritico;
	}
	
	/** Establece el nombre del arma
	 *  @param nombre nombre del arma
	 **/
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	/** Establece el daño extra del arma
	 *  @param danoExtra daño extra del arma
	 **/
	public void setDanoExtra(int danoExtra) {
		this.danoExtra = danoExtra;
	}
	/** Establece la precision de no fallar un ataque
	 *  @param precision Precision del arma
	 **/
	public void setPrecision(double precision) {
		this.precision = precision;
	}
	
	/** Establece la probabilidad de critico del arma
	 *  @param probabilidadCritico probabilidad de estunear
	 **/
	public void setProbabilidadCritico(double probabilidadCritico) {
		this.probabilidadCritico = probabilidadCritico;
	}
	
	
	
	
}
