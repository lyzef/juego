package juegoDePelea;

import java.util.Scanner;

import bitacora.GestorDeInformacion;
import bitacora.GestorDeInformacion;
import efectos.Efecto;
import personajes.Personaje;

public class Partida {
	GestorDeInformacion gestorDeInformacion;
	GestorPersonajes gestorPersonajes;
	int turno = 1; // 1 o 2
	
	Personaje[] personajesJugador;
	int numeroPersonajesJugadorEnTurno;
	
	Personaje[] personajesEnemigo;
	int numeroPersonajesEnemigoEnTurno;
	
	int personajesUsadosTurno = 0; 
	boolean partidaEnCurso = false;
	
	public Partida(GestorDeInformacion gestorDeInformacion, GestorPersonajes gestorPersonajes) {
		this.gestorDeInformacion = gestorDeInformacion;
		this.gestorPersonajes = gestorPersonajes;
		
	}
	// Crea metodo enTurno
	//Separar de iniciarPartida
	public boolean iniciarPartida() { 
		partidaEnCurso = true;
		boolean inicio = true;
		System.out.println("Iniciando partida...");
		//Validando listas de personaje
		if(Utilidades.listaVacia(gestorPersonajes.personajesJugador1)) {
			gestorDeInformacion.imprimirError("Jugador 1 no ha elegido personaje");
			return false;
		}
		if(Utilidades.listaVacia(gestorPersonajes.personajesJugador2)) {
			gestorDeInformacion.imprimirError("Jugador 2 no ha elegido personaje");
			return false;
		}
		
		
		while(partidaEnCurso) {
			//Variables de turno
			numeroPersonajesJugadorEnTurno = gestorPersonajes.numeroPersonajes[turno-1];
			numeroPersonajesEnemigoEnTurno = (turno == 1) ? gestorPersonajes.numeroPersonajes[0] : gestorPersonajes.numeroPersonajes[1];
			personajesEnemigo = (turno == 1) ? gestorPersonajes.personajesJugador2 : gestorPersonajes.personajesJugador1;
			personajesJugador = (turno == 1) ? gestorPersonajes.personajesJugador1 : gestorPersonajes.personajesJugador2;
			personajesUsadosTurno = 0; 
			//Efectos persistentes
			if(inicio) {
				turnoEnPartida();
				turno = (turno == 1) ? 2 : 1;
				inicio = false;
				continue;
			}
			gestorDeInformacion.imprimirTitulo("CAMBIO DE TURNO","-");
			gestorDeInformacion.imprimirTitulo("APLICANDO EFECTOS EN JUGADOR " + ((turno == 1) ? 2 : 1), "-");
			ejecutarEfectos(personajesEnemigo);
			partidaEnCurso = !verificarGanador();
			
			gestorDeInformacion.imprimirTitulo("APLICANDO EFECTOS EN JUGADOR " + turno, "-");
			ejecutarEfectos(personajesJugador);
			partidaEnCurso = !verificarGanador();
			
			if(partidaEnCurso == false) {continue;} //Fin de juego
			turnoEnPartida();
			turno = (turno == 1) ? 2 : 1;

		}
		System.out.println("FIN");
		return true;
	}
	//Controla el turno
	public void turnoEnPartida() {
		Scanner in = new Scanner(System.in);
		for(int i= 0; i < numeroPersonajesJugadorEnTurno; i++) { //Bucle de personajes
			if(partidaEnCurso == false) { //ganador
				break;
			}
			Personaje personajeActual = personajesJugador[personajesUsadosTurno];
			boolean cambioDeTurno = false;
			while(!cambioDeTurno && partidaEnCurso && !personajeActual.getStuneado() && !personajeActual.estaMuerto()) { //Bucle para cachar opciones y evitar stuneos y fin de juego
				gestorDeInformacion.imprimirTitulo(("Turno de jugador " + turno), "=");
				System.out.println("Personajes restantes = " + (numeroPersonajesJugadorEnTurno - personajesUsadosTurno));
				gestorDeInformacion.imprimir("Personaje activo: ", false);
				gestorDeInformacion.imprimirAlFinal( personajeActual.getNombre() + "(" + personajeActual.getTipo() + ")");
				System.out.println("1) Atacar");
				System.out.println("2) Usar habilidad");
				System.out.println("3) Ver estadisticas");
				System.out.println("4) Ver registro de batalla");	
				
				String eleccion = in.nextLine();
				if(eleccion.length() <= 0) { 
					System.out.println("Digita una opcion");
					continue;
				}
				
				switch(eleccion.charAt(0)) {
				case '1':
					cambioDeTurno = ataque(personajeActual);
					break;
				case '2':
					cambioDeTurno = ejecutarHabilidad(personajeActual);
					break;
				case '3':
					gestorDeInformacion.imprimirTitulo("ESTADISTICAS DE "+personajeActual.getNombre(), "-");
					personajeActual.mostrarEstadisticas();
					break;
				case '4':
					break;
				default:
					System.out.println("ELIGE OTRA OPCION");
				}
			}
			
			partidaEnCurso = !verificarGanador();
			if(cambioDeTurno) { //Stuneos y cambio de turno
				personajesUsadosTurno++;
			} else if(personajeActual.getStuneado()) {
				gestorDeInformacion.imprimirTitulo("INFO", "-");
				personajeActual.setStuneado(false);
				System.out.println("* "+personajeActual.getNombre() + " se encuentra stuneado");
				personajesUsadosTurno++;
			} else if(personajeActual.estaMuerto()) {
				gestorDeInformacion.imprimirTitulo("INFO", "-");
				System.out.println("**"+personajeActual.getNombre() + " se encuentra muerto");
				personajesUsadosTurno++;
			}
		}
		//--
	}
	//Controla las acciones de atacar del personaje y valida opciones
	public boolean ataque(Personaje personajeActual) {
		//Personaje enemigo a atacar
		boolean enemigoAtacado = false;
		int IndiceListaPersonajesEnemigo;
		while(!enemigoAtacado) {
			gestorDeInformacion.imprimirTitulo("ELIGE UN PERSONAJE A ATACAR", "=");
			verListaPersonajes(personajesEnemigo);
			System.out.println("9.- Salir");
			IndiceListaPersonajesEnemigo = recibirDatoInt(1, numeroPersonajesEnemigoEnTurno,9);
			gestorDeInformacion.imprimirTitulo("MENSAJES", "=");
			
			if(IndiceListaPersonajesEnemigo < 0) { //Personaje fuera de rango
				System.out.println("Elige un personaje");
				continue;
			} else if(IndiceListaPersonajesEnemigo == 9) {
				return false;
			}
			IndiceListaPersonajesEnemigo--;
			if(personajesEnemigo[IndiceListaPersonajesEnemigo].getVidaActual() == 0) {
				System.out.println("Personaje muerto... ELIGE OTRO");
				continue;
			} 
			personajeActual.atacar(personajesEnemigo[IndiceListaPersonajesEnemigo]);
			enemigoAtacado = true;
			gestorDeInformacion.imprimirTitulo("ESTADISTICAS DE PERSONAJE ATACADO", "=");
			personajesEnemigo[IndiceListaPersonajesEnemigo].mostrarEstadisticas();
		}
		return true;
	}
	
	public boolean ejecutarHabilidad(Personaje PersonajeActual) {
		//Casos especiales
		Personaje[] listaPersonajesAafectar = personajesEnemigo;
		int numeroDePersonajesPosiblesAafectar = numeroPersonajesEnemigoEnTurno;
		//if() //Clase sanadora
		
		boolean seguir = true;
		do {
			gestorDeInformacion.imprimirTitulo("LANZAR HABILIDAD", "=");
			System.out.println("Habilidad: " + PersonajeActual.getDescripcionHabilidad());
			verListaPersonajes(listaPersonajesAafectar);
			System.out.println("9.-Salir");
			int eleccion = recibirDatoInt(0, numeroDePersonajesPosiblesAafectar,9);
			gestorDeInformacion.imprimirTitulo("MENSAJES", "=");
			if(eleccion == -1) {
				gestorDeInformacion.imprimirError("Eleccion invalida, elige otro");
				continue;
			}  else if(eleccion == 9) {
				return false;
			}
			eleccion--;  //coincide con la lista
			if(listaPersonajesAafectar[eleccion].getVidaActual() == 0) {
				gestorDeInformacion.imprimirError("Personaje muerto, elige otro");
				continue;
			}else if(!PersonajeActual.habilidad(listaPersonajesAafectar[eleccion])) {
				System.out.println("Ups ... La habilidad no le hizo efecto a " + listaPersonajesAafectar[eleccion].getTipo()) ;
				
			}
			seguir = false;
		}while(seguir);
		return true;
	}
	public void ejecutarEfectos(Personaje[] listaPersonaje) {
		for(int i = 0; i < listaPersonaje.length; i++) {
			if(listaPersonaje[i].getVidaActual() == 0) {
				continue;
			}
			Efecto[] listaEfectos = listaPersonaje[i].getEfectos();
			for(int j = 0; j < listaEfectos.length;j++) {
				if(listaEfectos[j] == null) {
					continue;
				}
				listaEfectos[j].ejecutar(); //Sysout en clase
				if(listaEfectos[j].turnosEfecto == 0) {
					gestorDeInformacion.imprimirCaducadoEfecto(listaPersonaje[i], listaEfectos[j]);
					listaEfectos[j] = null;
				}
				
			}
		}
	 
	};
	
	public void verListaPersonajes(Personaje[] listaPersonaje) {
		for(int i = 0; i < listaPersonaje.length; i++) {
			if(listaPersonaje[i] != null) {
				String texto = (i+1)+ ".- " + listaPersonaje[i].getNombre() + "[" +listaPersonaje[i].getTipo()+ "] ";
				texto = texto + ((listaPersonaje[i].getVidaActual() == 0) ? "[MUERTO]" : "[VIDA "+listaPersonaje[i].getVidaActual() +"/"+listaPersonaje[i].getVidaMaxima()+ "] [ATK " + listaPersonaje[i].getPoderAtaque() + "]");
				texto = texto + ((listaPersonaje[i].getStuneado() == true) ? "[STUNEADO]" : "");
				System.out.println(texto);
			}
		}
	}
	
	public int recibirDatoInt(int limiteInferior, int limiteSuperior,int excepcion) {
		Scanner in = new Scanner(System.in);
		String dato = in.nextLine();
		if(dato.isBlank()) {
			return -1;
		}
		if (dato.charAt(0) < '0' || dato.charAt(0) > '9') {
			return -1;
		}
		
		int datoEntero = dato.charAt(0) - '0';
		if(datoEntero == excepcion) {
			return datoEntero;
		}
		if(datoEntero < limiteInferior || datoEntero > limiteSuperior) {
			return -1;
		} // Dato no es blanco, es int y esta entre los Li y Ls
		return datoEntero;
	}
	
	//Ganador es turno (1-2) o 0 si nadie a ganado
	public boolean verificarGanador() {
		Personaje[][] listasPersonajes=  {personajesJugador,personajesEnemigo};
		int turnoGanador = 0;
		for(int i = 0; i < listasPersonajes.length; i++) {
			boolean personajeVivo = false;
			
			for(Personaje personaje : listasPersonajes[i]) {
				if(personaje != null && !personaje.estaMuerto()) {
					personajeVivo = true;
					break;
				}
			}
			if(personajeVivo == false) { //ganador encontrado
				turnoGanador = (i == 0) ? (turno == 1 ? 2 : 1 ): turno;
				gestorDeInformacion.imprimirTitulo("JUEGO TERMINADO, " + "GANADOR JUGADOR " + turnoGanador, "=");
				System.out.println(turno);
				//Aqui ira el registro de la bitacora
				
				return true;
			}
			
		}
		
		return false;
	}
	
}


