package juegoDePelea;

public class Utilidades {
	public static <t> boolean listaVacia(t[] elementos) {
		for(int i = 0; i < elementos.length; i++) {
			if(elementos[i] != null) {
				return false;
			}
		}
		return true;
	}
	
	public static <t> boolean listaLlena(t[] elementos) {
		int elementosOcupados = 0;
		for(int i = 0; i < elementos.length; i++) {
			if(elementos[i] != null) {
				elementosOcupados++;
			}
		}
		
		if(elementosOcupados == elementos.length) {
			return true;
		}
		return false;
	}
	
	public static <t> int espacioVacioLista(t[] elementos) {
		for(int i = 0; i < elementos.length; i++) {
			if(elementos[i] == null) {
				return i;
			}
		}
		return -1;
	}
	
	public static <t> boolean buscarElementoEnListo(t[] elementos,t elemento) {
		for(int i = 0; i < elementos.length; i++) {
			if(elementos[i] == elemento) {
				return true;
			}
		}
		return false;
	}
	
	public static <t> int regresarIndiceElementoEnListo(t[] elementos,t elemento) {
		for(int i = 0; i < elementos.length; i++) {
			if(elementos[i] == elemento) {
				return i;
			}
		}
		return -1;
	}
}
