package juegoDePelea;

import java.util.Scanner;

import bitacora.Bitacora;
import bitacora.GestorDeInformacion;
import personajes.Espadachin;
import personajes.Mago;
import personajes.Personaje;
import personajes.Pistolero;

import java.lang.Character;
/**
 * Gestiona los personajes del juego, muestra los personajes base, gestiona los personajes de los jugadores
 * y establece los que se usaran para jugar
 * @see Partida
 * @see Personaje
 */
public class GestorPersonajes {
	/**Usada para facilitar la impresion de diseños o mensajes mas elaborados ademas de administrar el flujo de datos */
	GestorDeInformacion gestorDeInformacion;
	/**Todos los personajes del juego*/
	Personaje[] personajesBase = new Personaje[8];
	/**Personajes elegidos del jugador 1*/
	Personaje[] personajesJugador1 = new Personaje[3];
	

	/**Lista con los numeros de personajes de ambos jugadores */
	int numeroPersonajes[] = {0,0}; // 1 y 2
	/**Personajes elegidos del jugador 2*/
	Personaje[] personajesJugador2 = new Personaje[3];
	
	
	Arma arma = new Arma("Fierro",2,0.95,0.15); //0.15

	/**
	 * Inicializa la clase, añade los personajes base a lista de personajes base
	 * @param gestorDeInformacion usada para imprimir ajuste a parametros globlales
     */
	public GestorPersonajes(GestorDeInformacion gestorDeInformacion) {
		this.gestorDeInformacion = gestorDeInformacion;
		Personaje espadachin = new Espadachin("Espadachin",2000,arma,1,gestorDeInformacion);
		Personaje pistolero = new Pistolero("Pistolero",2000,arma,1,gestorDeInformacion);
		Personaje mago = new Mago("Mago",2000,arma,3,gestorDeInformacion);
		personajesBase[0] = espadachin;
		personajesBase[1] = pistolero;
		personajesBase[2] = mago;
	}
	

	public Personaje[] getPersonajesBase() {
		return personajesBase;
	}

	public Personaje[] getPersonajesJugador1() {
		return personajesJugador1;
	}

	public int[] getNumeroPersonajes() {
		return numeroPersonajes;
	}

	public Personaje[] getPersonajesJugador2() {
		return personajesJugador2;
	}

	public void setPersonajesBase(Personaje[] personajesBase) {
		this.personajesBase = personajesBase;
	}

	public void setPersonajesJugador1(Personaje[] personajesJugador1) {
		this.personajesJugador1 = personajesJugador1;
	}

	public void setNumeroPersonajes(int[] numeroPersonajes) {
		this.numeroPersonajes = numeroPersonajes;
	}

	public void setPersonajesJugador2(Personaje[] personajesJugador2) {
		this.personajesJugador2 = personajesJugador2;
	}
	public void setGestorDeInformacion(GestorDeInformacion gestorDeInformacion) {
		this.gestorDeInformacion = gestorDeInformacion;
	}
	
	/**
     * Selecciona un personaje existente y entra a su metodo mostrar estadisticas
     */
	public void verYElegirEstadisticasPersonajeBase() {
		Scanner in = new Scanner(System.in);
		int eleccion;
		boolean seguir = true;
		do {
			gestorDeInformacion.imprimirTitulo("LISTA DE PERSONAJES", "=");
			imprimirListaPersonajes();
			gestorDeInformacion.imprimir("Digita 9 para salir", true);
			gestorDeInformacion.imprimir("Digita el numero de un personaje para ver sus estadisticas", true);
			
			eleccion = regresarEnteroEnArregloDePersonaje(personajesBase, 9); //El personaje existe y esta dentro de la lista
			if(eleccion == 9) {
				return;
			} 
			if(eleccion == -1) {
				gestorDeInformacion.imprimirError("Opcion no existente, elige otra opcion");
				continue;
			}
			gestorDeInformacion.imprimirTitulo("ESTADISTICAS", "=");
			personajesBase[eleccion].mostrarEstadisticas();
			seguir = false;
		}while(seguir);
		
	}
	/**
	 * El jugador elige sus 3 personajes antes del combate, valida y agrega a lista
	 * de personajes propia, si ya existe muestra personajes elegidos
	 * @param jugador Jugador elegido
	 */
	public void elegirPersonajes(int jugador) {
		Personaje[] personajesJugador;
		if(jugador == 1) {
			personajesJugador = personajesJugador1;
		} else {
			personajesJugador = personajesJugador2;
		}
		//Validaciones
		if(!Utilidades.listaVacia(personajesJugador)) { //Mensaje de personajes ya elegidos
			gestorDeInformacion.imprimir("El jugador "+ jugador +" ya a elegido personajes", true);
			gestorDeInformacion.imprimir(personajesJugador[0].getNombre() +"("+ personajesJugador[0].getTipo()+")", true);
			gestorDeInformacion.imprimir(personajesJugador[1].getNombre() +"("+ personajesJugador[1].getTipo()+")", true);
			gestorDeInformacion.imprimir(personajesJugador[2].getNombre() +"("+ personajesJugador[2].getTipo()+")", true);
			return;
		}
		int personajesAgregados = 0;
		do {
			gestorDeInformacion.imprimirTitulo("ELIGE PERSONAJES PARA EL JUGADOR "+jugador,"=");
			for(int i = 0; i < personajesBase.length; i++) {//Lista de personajes y personajes elegidos
				if(personajesBase[i] == null) { continue;}
				String texto =(i+1) + ". " + personajesBase[i].getTipo();

				for(int j = 0; j < personajesJugador.length; j++) { //Alertar personajes ya elegidos
					if(personajesJugador[j] == null) {continue;}
					if(personajesBase[i].getClass() == personajesJugador[j].getClass()) {
						texto = i+1 + ". " + personajesBase[i].getTipo() + "-YA ELEGIDO";
						break;
					}
				}
				gestorDeInformacion.imprimir(texto, true);
			} 
			gestorDeInformacion.imprimir("Elige el personaje "+ (personajesAgregados+1), true); //Descarta excepciones y esta en rango de lista base
			int eleccion = regresarEnteroEnArregloDePersonaje(personajesBase,12000);
			if(eleccion == -1) {
				gestorDeInformacion.imprimir("Introduce un numero valido", true);
				continue;
			}
			//Buscando eleccion repetida
			boolean personajeRepetido = false;
			for(int j = 0; j < personajesJugador.length; j++) { //Alertar personajes ya elegidos
				if(personajesJugador[j] == null) {continue;}
				if(personajesBase[eleccion].getClass() == personajesJugador[j].getClass()) {
					personajeRepetido = true;
					gestorDeInformacion.imprimir("PERSONAJE YA ELEGIDO", true);
					gestorDeInformacion.imprimir("ELIGE OTRO", true);
					break;
				}
			}
			if(personajeRepetido) {continue;}
			//Creando y asignando personajes
			personajesJugador[personajesAgregados] = crearPersonaje(eleccion);
			//Asignando pertenencia de personaje a x jugador
			personajesJugador[personajesAgregados].setNombre(personajesJugador[personajesAgregados].getNombre()+" J"+jugador);
			
			gestorDeInformacion.imprimir("ELEGISTE: " + personajesJugador[personajesAgregados].getTipo(), true);
			personajesAgregados++;
		}while(personajesAgregados < 3);
		numeroPersonajes[jugador-1] = 3;
		gestorDeInformacion.imprimirTitulo("Personajes elegidos","=");
		gestorDeInformacion.imprimir(personajesJugador[0].getNombre() +"("+ personajesJugador[0].getTipo()+")", true);
		gestorDeInformacion.imprimir(personajesJugador[1].getNombre() +"("+ personajesJugador[1].getTipo()+")", true);
		gestorDeInformacion.imprimir(personajesJugador[2].getNombre() +"("+ personajesJugador[2].getTipo()+")", true);
	}
	
	/**
	 * regresa el indice de un elemento existente dentro de una tabla pasada como 
	 * parametro, valida su existencia y permite excepciones
	 * @param personajes Lista en donde comparar
	 * @param numeroExepcion Numero a exeptuar de verificacion
	 * @return Numero entero validado
	 */
	public int regresarEnteroEnArregloDePersonaje(Personaje[] personajes,int numeroExcepcion) {
		Scanner in = new Scanner(System.in);
		String eleccion = in.nextLine();
		
		if(eleccion.isEmpty()) {
			return -1;
		} else if(!Character.isDigit(eleccion.charAt(0))) {
			return -1;
		} //El char existe y es un digito
		
		int nPersonaje = eleccion.charAt(0) - '0';
		
		//EXEPCION (numero especial que no esya en la lista)
		if(nPersonaje == numeroExcepcion) {
			return nPersonaje;
		}
		nPersonaje--;
		
		
		if(nPersonaje >= personajes.length || nPersonaje < 0 || personajes[nPersonaje] == null) {
			return -1;
		}
		//Numero no es nulo en lista y es mayor que 0
		return nPersonaje;
	}
	
	/**
	 * Imprime lista de personajes base, evita los nulos
	 */
	public void imprimirListaPersonajes() {
		for(int i = 0; i < personajesBase.length; i++) {
			if(personajesBase[i] == null) { continue;}
			String texto = i+1 + ". " + personajesBase[i].getTipo();
			gestorDeInformacion.imprimir(texto, true);
		}
	}
	
	/**
	 * 	Crea un personaje base
     * @param indicePersonajeBase Pertenciente a lista de personajes base
     * @return regresa el personaje creado o si no existe en lista base uno nulo
     */
	public Personaje crearPersonaje(int indicePersonajeBase) {
		Personaje p;
		switch(indicePersonajeBase) {
		case 0:
			p = new Espadachin("DON PANCHO", 1200, arma, 1, gestorDeInformacion);
			break;
		case 1:
			p = new Pistolero("PISTOLERA", 12222, arma, 1, gestorDeInformacion);
			break;
		case 2:
			p = new Mago("MAGO",2000,arma,3,gestorDeInformacion);
			break;
		default:
			return null;
		}
		
		return p;
	}
	
	
	
}
