package efectos;

import bitacora.GestorDeInformacion;
import personajes.Personaje;
import personajes.Pistolero;
/**
 * Aplica un disparo asegurado al inicio de cada ronda sin aplicar un gasto de accion para el pistolero
 * para si el pistolero es atacado o el objetivo muere
 * @see Pistolero
 */
public class ObjetivoFijo extends Efecto{
	/** Personaje objetivo del ataque garantizado del pistolero*/
	/**
	 * 	Construye la clase objetivo fijo, habilita el uso de la habilidad especial del pistolero
	 * 	funciona ligeramente diferente a la mayoria de efectos
	 * 	@param personajePistolero Personaje que disparo el efecto, este efecto se queda en su lista de efectos
	 *  @param objetivo Objetivo del disparo garantizado cada turno
	 *  */
	public ObjetivoFijo(Personaje personajePistolero, Personaje objetivo,GestorDeInformacion gestorDeInformacion) {
		super("Objetivo asegurado", true, 22000, objetivo,personajePistolero,gestorDeInformacion);
		Pistolero pistolero = (Pistolero) personajePistolero;
		pistolero.setHabilidadActiva(true);
	}

	
	/** Ejecuta el disparo garantizado cada turno asi como determina si aun sigue funcional la habilidad */
	@Override
	public void ejecutar() {
		Pistolero pistolero = (Pistolero) personajeOrigenEfecto; //DownCasting
		if(pistolero.isHabilidadActiva()) {
			pistolero.atacar(personajeAfectado);
			if(personajeAfectado.getVidaActual() == 0) { //Objetivo murio
				turnosEfecto = 0;
			}
			System.out.println(personajeAfectado.getTipo() + " dañado por " + nombre);
			System.out.println();
		} else {
			turnosEfecto = 0;
		}
		
	}
	
}
