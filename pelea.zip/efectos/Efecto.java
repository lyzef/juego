package efectos;

import bitacora.Bitacora;
import bitacora.GestorDeInformacion;
import personajes.Personaje;
/**
 * Representa la clase abstracta de los efectos, tiene la mayoria de parametros necesarios para estos
 * se alojan comunmente en la lista de efectos ubicada en cada personaje
 * @see Personaje
 */
public abstract class Efecto {
	/** Nombre del efecto. */
	public String nombre;
	/** Persistencia del efecto en varios turnos */
	public boolean persistente;
	/** Numero de turnos en donde afectara al personaje */
	public int turnosEfecto;
	/** Personaje afectado por el efecto */
	public Personaje personajeAfectado;
	/** Personaje afectado por el efecto */
	public Personaje personajeOrigenEfecto;
	/** Bitacora */
	GestorDeInformacion gestorDeInformacion;
	/**
	 * Construye la clase efecto usada como base de los distintos efectos en el juego
	 * @param nombre Nombre del efecto
	 * @param persistente Si el efecto dura varios turnos
	 * @param turnosEfecto Numero de turnos que durara el efecto
	 * @param personajeAfectado personaje en donde se alojara el efecto y en la mayoria de casos afectara negativamente
	 */
	public Efecto(String nombre,boolean persistente, int turnosEfecto,Personaje personajeAfectado, Personaje personajeOrigenEfecto,GestorDeInformacion gestorDeInformacion) {
		this.nombre = nombre;
		this.persistente = persistente;
		this.turnosEfecto = turnosEfecto;
		this.personajeAfectado = personajeAfectado;
		this.personajeOrigenEfecto = personajeOrigenEfecto;
		this.gestorDeInformacion = gestorDeInformacion;
	}
	
	public String getNombre() {
		return nombre;
	}

	public boolean isPersistente() {
		return persistente;
	}

	public int getTurnosEfecto() {
		return turnosEfecto;
	}

	public Personaje getPersonajeAfectado() {
		return personajeAfectado;
	}

	public Personaje getPersonajeOrigenEfecto() {
		return personajeOrigenEfecto;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public void setPersistente(boolean persistente) {
		this.persistente = persistente;
	}

	public void setTurnosEfecto(int turnosEfecto) {
		this.turnosEfecto = turnosEfecto;
	}

	public void setPersonajeAfectado(Personaje personajeAfectado) {
		this.personajeAfectado = personajeAfectado;
	}

	public void setPersonajeOrigenEfecto(Personaje personajeOrigenEfecto) {
		this.personajeOrigenEfecto = personajeOrigenEfecto;
	}

	/**
	 * Ejecuta los efectos en el personaje afectado en la mayoria de las veces, puede aplicar buff, debuff, daños o curacion
	 */
	public abstract void ejecutar();
}
