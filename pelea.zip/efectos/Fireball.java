package efectos;

import bitacora.Bitacora;
import bitacora.GestorDeInformacion;
import personajes.Mago;
import personajes.Personaje;
/**
 * Aplica daño al ejecutarse por primera vez, despues de eso genera un quemadura tras cada turno
 * @see Mago
 */
public class Fireball extends Efecto {
	/**Indica si la fireball se encuentra en su primera interaccion con el personaje afectado */
	boolean efectoInstantaneo = false;
	
	/** 
	 *  Construye la clase fireball
	 *  @param personajeAfectado personaje en donde se aplica el daño al instante y la quemadura persistente
	 * */
	public Fireball(Personaje personajeAfectado, Personaje personajeOrigenEfecto,GestorDeInformacion gestorDeInformacion) {
		super("Fireball", true, 3,personajeAfectado,personajeOrigenEfecto,gestorDeInformacion);
		
	}

	@Override
	/** Ejecuta el efecto de daño instantaneo o la quemadura si ya golpeo por primera vez
	 * */
	public void ejecutar() {
		if(!efectoInstantaneo) {
			personajeAfectado.recibirDaño(personajeOrigenEfecto,20);
			efectoInstantaneo = true;
		} else { //Quemadura
			int i = personajeAfectado.recibirDaño(personajeOrigenEfecto,5);
			System.out.println(personajeAfectado.getTipo()+ " ardiendo por " + nombre);
			System.out.println();
			turnosEfecto--;
		}
	}

}
