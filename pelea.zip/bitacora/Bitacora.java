package bitacora;

import adtListaEnlazada.ListaEnlazada;
import juegoDePelea.GestorPersonajes;
import juegoDePelea.Utilidades;
import personajes.Personaje;

public class Bitacora {
	GestorPersonajes gestorPersonajes;
	
	ListaEnlazada listaAcciones = new ListaEnlazada();
	int[] dañoTotalRealizadoPorPersonajeT1 = new int[5];
	int[] dañoTotalRealizadoPorPersonajeT2 = new int[5];
	
	int[] criticosPorPersonajesT1 = new int[5];
	int[] criticosPorPersonajesT2 = new int[5];
	
	int[] fallosPorPersonajeT1 = new int[5];
	int[] fallosPorPersonajeT2 = new int[5];
	
	int[] habilidadesUsadasT1 = new int[5];
	int[] habilidadesUsadasT2 = new int[5];
	
	Personaje[] ordenDeMuerteT1 = new Personaje[10];
	Personaje[] ordenDeMuerteT2 = new Personaje[10];
	
	/**
	 * Inicia la clase pasando dos clases de importancia para la manipulacion de la informacion y impresion de la misma
	 */
	public Bitacora() {

	}
	/**
	 * Establece clase necesaria para consultar listas de personajes
	 */
	public void setGestorPersonajes(GestorPersonajes gestorPersonajes) {
		this.gestorPersonajes = gestorPersonajes;
	}
	
	/**
	 * Crea y registra acciones dentro de la bitacora del juego
	 * clasifica los datos en varias listas que se usaran al final de la partida
	 * @see Partida
	 * @param accion Accion que describe el registro
	 * @param atacante Atacante o el que detona el evento
	 * @param objetivo Objetivo de la accion
	 * @param daño Daño en caso de que exista
	 * @param critico Si hubo stuneo
	 * @param fallo Si fallo un ataque
	 * @param habilidad Si la accion fue una habilidad
	 * @param muerte Si el objetivo murio
	 */
	public void agregar(String accion, Personaje atacante, Personaje objetivo, int daño, boolean critico, boolean fallo,boolean habilidad,boolean muerte) {
		RegistroDeCombate registro = new RegistroDeCombate(accion, atacante, objetivo, daño, critico, fallo);
		listaAcciones.agregar(registro);
		//Obtiendo turno de ambos personajes
		String turnoAtacante = atacante.getNombre().substring(atacante.getNombre().length()-1);
		int indiceAtacante = (turnoAtacante == "1") ? Utilidades.regresarIndiceElementoEnListo(gestorPersonajes.getPersonajesJugador1(), atacante)
				: Utilidades.regresarIndiceElementoEnListo(gestorPersonajes.getPersonajesJugador2(), atacante);
		String turnoObjetivo = objetivo.getNombre().substring(objetivo.getNombre().length()-1);
		int indiceObjetivo = (turnoObjetivo == "1") ? Utilidades.regresarIndiceElementoEnListo(gestorPersonajes.getPersonajesJugador1(), objetivo)
				: Utilidades.regresarIndiceElementoEnListo(gestorPersonajes.getPersonajesJugador2(), objetivo);
		//BUG AQUI
		System.out.println(turnoAtacante);
		System.out.println(indiceAtacante);
		System.out.println(turnoObjetivo);
		System.out.println(indiceObjetivo);
		//Registros de fin de partida
		if(daño > 0) {
			if(turnoAtacante == "1") {
				dañoTotalRealizadoPorPersonajeT1[indiceAtacante] += daño;
			} else {
				dañoTotalRealizadoPorPersonajeT2[indiceAtacante] += daño;
			}
		}
		
		if(critico) {
			if(turnoAtacante == "1") {
				criticosPorPersonajesT1[indiceAtacante] ++;
			} else {
				criticosPorPersonajesT2[indiceAtacante] ++;
			}
		}
		
		if(fallo) {
			if(turnoAtacante == "1") {
				fallosPorPersonajeT1[indiceAtacante] ++;
			} else {
				fallosPorPersonajeT2[indiceAtacante] ++;
			}
		}
		
		if(habilidad) {
			if(turnoAtacante == "1") {
				habilidadesUsadasT1[indiceAtacante] ++;
			} else {
				habilidadesUsadasT2[indiceAtacante] ++;
			}
		}
		
		if(muerte) {
			if(turnoObjetivo == "1") {
				ordenDeMuerteT1[Utilidades.espacioVacioLista(ordenDeMuerteT1)] = objetivo;
				
			} else {
				ordenDeMuerteT1[Utilidades.espacioVacioLista(ordenDeMuerteT2)] = objetivo;
			}
		}
		
	}
	/**
	 * Lee las 10 ultimas acciones reciente
	 */
	public void leerHistorial() {
		listaAcciones.imprimir(100);
	}
	/**
	 * Reinicia todos los parametros para iniciar una partida
	 */
	public void reiniciar() {
		while(listaAcciones.eliminarAlFinal()) {
		}
		dañoTotalRealizadoPorPersonajeT1 = new int[5];
		dañoTotalRealizadoPorPersonajeT2 = new int[5];
		
		criticosPorPersonajesT1 = new int[5];
		criticosPorPersonajesT2 = new int[5];
		
		fallosPorPersonajeT1 = new int[5];
		fallosPorPersonajeT2 = new int[5];
		
		habilidadesUsadasT1 = new int[5];
		habilidadesUsadasT2 = new int[5];
		
		ordenDeMuerteT1 = new Personaje[10];
		ordenDeMuerteT2 = new Personaje[10];
	}
	/**
	 * Imprime todos los parametros recabados de importancia en la partida
	 * divide la informacion por secciones, turno y personajes usados
	 */
	
}
