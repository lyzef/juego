package bitacora;

import efectos.Efecto;
import juegoDePelea.GestorPersonajes;
import personajes.Personaje;

public class GestorDeInformacion extends Bitacora{
	int resolucionX;
	int caracteresUsadosActual;
	
	public String RESET = "\u001b[0m";
    public String ROJO = "\u001b[31m";
    public String VERDE = "\u001b[32m";
    public String AZUL = "\u001b[34m";
    public String AMARILLO = "\u001b[33m";
    public String CYAN = "\u001b[36m";
    public String MAGENTA = "\u001b[39m";
    
	public GestorDeInformacion(int resolucionX) {
		super();
		caracteresUsadosActual = 0;
		if(resolucionX < 20) { //tamano minimo
			this.resolucionX = 20;
			return;
		}
		this.resolucionX = resolucionX;
	}
	
	private void imprimirMismoCaracter(char caracter,int veces) {
		for(int i = 0; i < veces; i++) {
			System.out.print(caracter);
		}
	}
	
	public void imprimirTitulo(String texto,String separador) {
		int longitud = texto.length();
		char linea = separador.charAt(0);
		int espacioEntreTituloYLinea = 1;
		
		int alineacionAlMedio = (resolucionX/2) - longitud/2 - espacioEntreTituloYLinea;
		int totalCaracteresImprimidos = 0;
		
		//Primera parte
		System.out.println();
		imprimirMismoCaracter(linea, alineacionAlMedio); totalCaracteresImprimidos += alineacionAlMedio;
		imprimirMismoCaracter(' ', espacioEntreTituloYLinea); totalCaracteresImprimidos+= espacioEntreTituloYLinea;
		System.out.print(CYAN+texto+RESET); totalCaracteresImprimidos += texto.length();
		imprimirMismoCaracter(' ', espacioEntreTituloYLinea); totalCaracteresImprimidos+= espacioEntreTituloYLinea;
		imprimirMismoCaracter(linea, resolucionX - totalCaracteresImprimidos);
		
		System.out.println();
		caracteresUsadosActual = 0;
	}
	
	public void imprimirAlFinal(String texto) {
		int longitud = texto.length();
		int alineacionAlFinal = (int)(resolucionX*0.6);
		alineacionAlFinal -= caracteresUsadosActual;
		
		imprimirMismoCaracter(' ', alineacionAlFinal);
		System.out.println(texto);
		caracteresUsadosActual = 0;
	}
	
	public void imprimir(String texto,boolean saltoDeLinea) {
		if(saltoDeLinea) {
			System.out.println(texto);
			caracteresUsadosActual = 0;
		} else {
			caracteresUsadosActual += texto.length();
			System.out.print(texto);
		}
		
	}
	public void imprimirSubtitulo(String texto) {
		System.out.println(VERDE+"*- "+RESET + texto);
	}
	public void imprimirSubirNivel(Personaje personaje, int nivel ) {
		System.out.println("["+VERDE+personaje.getNombre() +RESET+"] ha subido a nivel "+ nivel);
		agregar("Subio de nivel",personaje,personaje, 0, false, false, false, false);
	}
	
	public void imprimirMuerte(Personaje asesino, Personaje muerto,int daño) {
		System.out.println("["+ROJO+muerto.getNombre()+RESET+"]"+ " a muerto por "+"["+AMARILLO+asesino.getNombre()+RESET+"]");
		agregar("Asesino a ", asesino, muerto, daño, false, false, false, true);
	}
	
	public void imprimirError(String texto) {
		System.out.println("["+ROJO+"ERROR"+RESET+"] "+ texto);
	}
	
	public void imprimirGolpe(Personaje atacante, Personaje atacado, int dañoCausado) {
		System.out.println("["+AMARILLO+atacante.getNombre()+RESET+"] ataco a "+"["+AMARILLO+atacado.getNombre()+RESET+"] por ["+ROJO+dañoCausado+RESET+"] puntos de daño");
		agregar("ataco a ", atacante, atacado, dañoCausado, false, false, false, false);
	}
	
	public void imprimirCaducadoEfecto(Personaje personajeConElEfecto, Efecto efecto) {
		System.out.println(efecto.getNombre()+" a expirado en ["+AMARILLO+personajeConElEfecto.getNombre()+RESET+"]");
	}
	
	public void imprimirAtaqueFallido(Personaje atacante, Personaje atacado) {
		System.out.println("Tu ataque a ["+CYAN+atacado.getNombre()+RESET+"] a ["+ROJO+"FALLADO"+RESET+"]");
		agregar("fallo un golpe a", atacante, atacado, 0, false, true, false, false);
	}
	
	public void imprimirCritico(Personaje atacante, Personaje atacado) {
		System.out.println("Tu ataque a ["+CYAN+atacado.getNombre()+RESET+"] lo ["+ROJO+"STUNEO"+RESET+"]");
		agregar("acerto un critico a", atacante, atacado, 0, true, false, false, false);
	}
	
	public void habilidad(Personaje atacante,String habilidad ,Personaje atacado) {
		System.out.println("["+AMARILLO+atacante.getNombre()+RESET+"] uso "+habilidad+" en ["+AMARILLO+atacado.getNombre()+RESET+"]");
		agregar("uso "+habilidad+" en", atacante, atacado, 0, false, false, true, false);
	}
	
	public void resumenFinal() {
		imprimirTitulo("RESUMEN FINAL", "-");
		imprimir("*Orden de personajes en morir", true);
		imprimir("**Turno 1:", false);
		for(Personaje p :ordenDeMuerteT1) {
			if(p != null) {
				imprimir(" -> "+p.getNombre(), false);
			}
		}
		imprimir("**Turno 2:", false);
		for(Personaje p :ordenDeMuerteT2) {
			if(p != null) {
				imprimir(" -> "+p.getNombre(), false);
			}
		}
		
		imprimirSubtitulo("Estadisticas por personaje");
		Personaje[] personajesJugador1 = gestorPersonajes.getPersonajesJugador1();
		Personaje[] personajesJugador2 = gestorPersonajes.getPersonajesJugador2();
		imprimirSubtitulo("Turno 1:");
		for(int i = 0; i < personajesJugador1.length; i++) {
			Personaje p = personajesJugador1[i];
			if(p==null) {continue;}
			imprimirSubtitulo(p.getNombre());
			imprimir("Daño total realizado:" , false);
			imprimirAlFinal(dañoTotalRealizadoPorPersonajeT1[i]+"");
			imprimir("Numero de habilidades usadas:" , false);
			imprimirAlFinal(habilidadesUsadasT1[i]+"");
			imprimir("Numero de golpes criticos acertados:" , false);
			imprimirAlFinal(criticosPorPersonajesT1[i]+"");
			imprimir("Numero de golpes fallados:" , false);
			imprimirAlFinal(fallosPorPersonajeT1[i]+"");
			imprimir("Nivel final alcanzado:" , false);
			imprimirAlFinal(p.getNivel()+"");
		}
		imprimirSubtitulo("Turno 2:");
		for(int i = 0; i < personajesJugador2.length; i++) {
			Personaje p = personajesJugador2[i];
			if(p==null) {continue;}
			imprimirSubtitulo(p.getNombre());
			imprimir("Daño total realizado:" , false);
			imprimirAlFinal(dañoTotalRealizadoPorPersonajeT2[i]+"");
			imprimir("Numero de habilidades usadas:" , false);
			imprimirAlFinal(habilidadesUsadasT2[i]+"");
			imprimir("Numero de golpes criticos acertados:" , false);
			imprimirAlFinal(criticosPorPersonajesT2[i]+"");
			imprimir("Numero de golpes fallados:" , false);
			imprimirAlFinal(fallosPorPersonajeT2[i]+"");
			imprimir("Nivel final alcanzado:" , false);
			imprimirAlFinal(p.getNivel()+"");
		}
		reiniciar();
	}
	
	
}
