package bitacora;

import personajes.Personaje;

public class RegistroDeCombate {
	private String accion;
	private Personaje atacante;
	private Personaje objetivo;
	private int daño;
	private boolean critico;
	private boolean fallo;
	/**
	 * Construye la clase registro de combate
	 * @param accion Accion del registro
	 * @param atacante Atacante si hay
	 * @param objetivo Objetivo de la accion
	 * @param daño Daño ejercico
	 * @param critico Si hubo algun critico como efecto
	 * @param fallo Si fallo algun ataque o similar
	 */
	public RegistroDeCombate(String accion, Personaje atacante, Personaje objetivo, int daño, boolean critico,boolean fallo) {
		this.accion = accion;
		this.atacante = atacante;
		this.objetivo = objetivo;
		this.daño = daño;
		this.critico = critico;
		this.fallo = fallo;
	}
	/**
	 * Muestra la informacion de un registro de combate 
	 */
	public void verInformacion() {
		String texto = atacante.getNombre()+" "+accion+" "+objetivo.getNombre()+", Daño a "+ objetivo.getNombre()+ " = " + daño;
		if(critico || fallo) {
			texto = texto + "\n"+((fallo = true) ? atacante.getNombre() + " fallo el ataque" : objetivo.getNombre() + " recibio un critico");
		}
		System.out.println(texto);
		
	}
}