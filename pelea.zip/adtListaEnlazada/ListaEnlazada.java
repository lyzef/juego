package adtListaEnlazada;

import bitacora.RegistroDeCombate;

public class ListaEnlazada {
    private Nodo nodoInicio;
    private Nodo nodoFin;
    private int tamaño;

    public ListaEnlazada() {
        nodoInicio = null;
        nodoFin = null;
        tamaño = 0;
    }

    public void agregar(RegistroDeCombate dato) {
        Nodo nodoNuevo = new Nodo(dato);
        if (nodoInicio == null) {
            nodoInicio = nodoNuevo;
            nodoFin = nodoNuevo;
        } else {
            nodoFin.setSiguiente(nodoNuevo);
            nodoFin = nodoNuevo;
        }
        tamaño++;
        System.out.println("[operacion: agregar] dato agregado a la lista: " + dato + " | tamaño actual: " + tamaño);
    }

    public void eliminar(String dato) {
        if (estaVacia()) {
            System.out.println("[operacion: eliminar] error: la lista esta vacia, no se puede eliminar");
            return;
        }

        if (dato == null) {
            System.out.println("[operacion: eliminar] error: el dato ingresado es invalido");
            return;
        }

        if (nodoInicio.getDato().equals(dato)) {
            System.out.println("[operacion: eliminar] eliminando nodo inicial: " + nodoInicio.getDato());
            nodoInicio = nodoInicio.getSiguiente();
            if (nodoInicio == null) { 
                nodoFin = null;
            }
            tamaño--;
            System.out.println("[operacion: eliminar] eliminacion exitosa | tamaño actual: " + tamaño);
            return;
        }

        Nodo anterior = nodoInicio;
        Nodo actual = nodoInicio.getSiguiente();

        while (actual != null) {
            if (actual.getDato().equals(dato)) {
                anterior.setSiguiente(actual.getSiguiente());
                
                if (actual == nodoFin) {
                    nodoFin = anterior;
                }
                
                tamaño--;
                System.out.println("[operacion: eliminar] dato encontrado y eliminado: " + dato + " | tamaño actual: " + tamaño);
                return;
            }
            anterior = actual;
            actual = actual.getSiguiente();
        }

        System.out.println("[operacion: eliminar] error: el dato '" + dato + "' no existe en la lista");
    }

    public boolean buscar(String dato) {
        Nodo n = nodoInicio;
        while (n != null) {
            if (n.getDato().equals(dato)) {
                return true;
            }
            n = n.getSiguiente();
        }
        return false;
    }

    public boolean estaVacia() {
        return nodoInicio == null;
    }

    public int getTamaño() {
        return tamaño;
    }

    public void imprimir(int numeroDeNodos) {
        if (estaVacia()) {
            System.out.println("[operacion: imprimir] lista vacia");
            return;
        }
        Nodo n = nodoInicio;
        System.out.print("[operacion: imprimir] lista: ");
        while (n != null && numeroDeNodos > 0) {
        	numeroDeNodos--;
        	System.out.print(n.getDato());
            n = n.getSiguiente();
            if(n != null) {
            	n.getDato().verInformacion();
            } else { System.out.println();}
        }
        System.out.println("| tamaño actual: " + tamaño+" |");
    }
    
    public boolean eliminarAlFinal() {
        if(estaVacia()) {
            return false;
        }
        
        if(nodoInicio.getSiguiente() == null) {
            nodoInicio = null;
            tamaño = 0;
            return true;
        }
        
        Nodo nodo = nodoInicio;
        Nodo nodoSiguiente = nodoInicio.getSiguiente();
        
        while(nodoSiguiente.getSiguiente() != null) {
            nodo = nodo.getSiguiente();
            nodoSiguiente = nodoSiguiente.getSiguiente();
        }
        
        tamaño--;
        nodo.setSiguiente(null);
        return true;
    }
}