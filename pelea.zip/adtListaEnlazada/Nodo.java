package adtListaEnlazada;

import bitacora.RegistroDeCombate;

public class Nodo {
	private Nodo siguiente;
	private RegistroDeCombate dato;
	
	public Nodo(RegistroDeCombate dato) {
		this.dato = dato;
		this.siguiente = null;
	}
	
	public RegistroDeCombate getDato() {
		return this.dato;
	}
	
	public void setDato(RegistroDeCombate dato) {
		this.dato = dato;
	}
	
	public Nodo getSiguiente() {
		return siguiente;
	}
	
	public void setSiguiente(Nodo siguiente) {
		this.siguiente = siguiente;
	}
}
